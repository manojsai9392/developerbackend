// src/pages/Dashboard.js

import React, { useState, useEffect } from 'react';
import { getMatchingDevelopers } from '../services/apiService';
import MatchCards from '../components/MatchCards';
import './dashboard.css'; // Make sure this path is correct

function Dashboard() {
    const [developers, setDevelopers] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchMatchingDevelopers = async () => {
            try {
                // Retrieve skills from localStorage or a state management solution
                const userSkills = JSON.parse(localStorage.getItem('userSkills')) || [];
                const data = await getMatchingDevelopers(userSkills);
                setDevelopers(data);
            } catch (error) {
                console.error('Error fetching matching developers:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchMatchingDevelopers();
    }, []);

    if (loading) return <p>Loading...</p>;

    return (
        <div className="dashboard-container">
            <h2>Matching Developers</h2>
            <MatchCards developers={developers} />
        </div>
    );
}

export default Dashboard;
