// src/components/MatchCards.js

import React from 'react';
import './dashboard.css'; // Make sure this path is correct

function MatchCards({ developers }) {
    return (
        <div className="match-cards-container">
            {developers.map((dev) => (
                <div key={dev.id} className="match-card">
                    <h3>{dev.username}</h3>
                    <p>Email: {dev.email}</p>
                    <p>Skills: {dev.skills.join(', ')}</p>
                    <p>Interests: {dev.interests.join(', ')}</p>
                </div>
            ))}
        </div>
    );
}

export default MatchCards;
