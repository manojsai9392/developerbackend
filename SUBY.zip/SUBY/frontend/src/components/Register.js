import React, { useState } from 'react';
import axios from 'axios';
import './styles.css'; // Make sure this path is correct
import Navbar from './Navbar'; // Import the Navbar component

function Register() {
    const [formData, setFormData] = useState({
        username: '',
        email: '',
        password: '',
        skills: '',
        interests: '',
        experienceLevel: 'Entry'
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            // Convert comma-separated strings to arrays if needed
            const skillsArray = formData.skills.split(',').map(skill => skill.trim());
            const interestsArray = formData.interests.split(',').map(interest => interest.trim());
    
            // Update form data
            const data = {
                ...formData,
                skills: skillsArray,
                interests: interestsArray
            };
    
            const response = await axios.post('http://localhost:5000/api/developers/register', data);
            alert(response.data.message);
        } catch (error) {
            console.error('Registration error:', error.response ? error.response.data : error.message); // Detailed frontend error logging
            alert('Error registering developer: ' + (error.response ? error.response.data.error : error.message));
        }
    };

    return (
        <div>
            <Navbar /> {/* Include the Navbar */}
            <div className="container">
                <h2>Register</h2>
                <form onSubmit={handleSubmit}>
                    <input type="text" name="username" value={formData.username} onChange={handleChange} placeholder="Username" required />
                    <input type="email" name="email" value={formData.email} onChange={handleChange} placeholder="Email" required />
                    <input type="password" name="password" value={formData.password} onChange={handleChange} placeholder="Password" required />
                    <input type="text" name="skills" value={formData.skills} onChange={handleChange} placeholder="Skills (comma separated)" required />
                    <input type="text" name="interests" value={formData.interests} onChange={handleChange} placeholder="Interests (comma separated)" required />
                    <select name="experienceLevel" value={formData.experienceLevel} onChange={handleChange}>
                        <option value="Entry">Entry</option>
                        <option value="Intermediate">Intermediate</option>
                        <option value="Experienced">Experienced</option>
                    </select>
                    <button type="submit">Register</button>
                </form>
            </div>
        </div>
    );
}

export default Register;
