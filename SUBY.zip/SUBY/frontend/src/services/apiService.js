// src/services/apiService.js

import axios from 'axios';

const API_URL = 'http://localhost:5000/api/developers';

export const getMatchingDevelopers = async (skills) => {
    try {
        const response = await axios.post(`${API_URL}/match`, { skills });
        return response.data;
    } catch (error) {
        console.error('Error fetching matching developers:', error);
        throw error;
    }
};
